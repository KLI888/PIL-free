import os

from celery import Celery
from celery.schedules import crontab 
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'hello.settings')

app = Celery('hello')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()

# celery beat
app.conf.beat_schedule = {
    'daily-payout-task': {
        'task': 'pil.task.daily_payout_task',
        'schedule': crontab(hour=9, minute=10)
    }
}


@app.task(bind=True, ignore_result=True)
def debug_task(self):
    print(f'Request: {self.request!r}')