from django.db import models
from django.contrib.auth.models import User
from django.core.management.base import BaseCommand
# Create your models here.
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.contrib.auth import get_user_model
from django.conf import settings
from datetime import timedelta



from django.contrib.auth.base_user import BaseUserManager

class UserManager(BaseUserManager):
    def create_user(self, phone_number, password= None, **extra_fields):
        if not phone_number:
            raise ValueError('Phone number is required')
        
        user = self.model(phone_number = phone_number, **extra_fields)
        user.set_password(password)
        user.save(using = self.db)

        return user
    
    def create_superuser(self, phone_number, password= None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)

        return self.create_user(phone_number, password, **extra_fields)
    



class CustomUser(AbstractUser):
    phone_number = models.CharField(max_length=20, unique=True)
    username = models.CharField(max_length=40, unique=False, default='')

    USERNAME_FIELD = 'phone_number'
    REQUIRED_FIELDS = []
    objects = UserManager()

    def __str__(self):
        return self.phone_number




# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


class WithdrawRequest(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    name = models.CharField(max_length=500)
    phone_number = models.CharField(max_length=13)
    user_email = models.CharField(max_length=500)
    user_upi = models.CharField(max_length=500)
    wid_amount = models.CharField(max_length=3)
    request_date = models.DateField(auto_now_add=True)
    

    def __str__(self):
        return f'{self.user} : name -> {self.name} : {self.request_date}'




class Product(models.Model):
    product_price = models.DecimalField(max_digits=10, decimal_places=2)
    product_img = models.ImageField(upload_to='static/assets/product/', default='/static/assets/p2.jpg')
    product_name = models.CharField(max_length=100)
    product_cycle = models.PositiveIntegerField()  # Number of days for the payout cycle
    product_daily = models.DecimalField(max_digits=10, decimal_places=2)  # Daily payout amount

    def __str__(self):
        return self.product_name

class Purchase(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    purchase_date = models.DateField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f'Purchase: {self.user} : {self.purchase_date}'


    def calculate_daily_payouts(self, total_days):
        # Calculate daily payouts for the purchased product
        daily_payout = self.product.product_daily
        payout_date = self.purchase_date
        total_payout_amount = 0  # Initialize total payout amount

        # Create DailyPayout instances for each day
        for day in range(1, total_days + 1):
            payout = DailyPayout(
                purchase=self,
                payout_amount=daily_payout,
                payout_date=payout_date
            )
            payout.save()

            # Increment the payout date by one day
            payout_date += timedelta(days=1)

            # Add the daily payout amount to the total
            total_payout_amount += daily_payout

        # Update the total payout amount for the purchase
        self.total_payout_amount = total_payout_amount
        self.save()

class DailyPayout(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    purchase = models.ForeignKey(Purchase, on_delete=models.CASCADE)
    payout_amount = models.DecimalField(max_digits=10, decimal_places=2)  # Daily payout amount
    payout_date = models.DateField(auto_now=False, auto_now_add=False)

    def __str__(self):
        return f'{self.payout_date}'


    









class UserEarn(models.Model):   
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    user_earnings = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    user_today_earnings = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    def __str__(self):
        return f"Earnings for User: {self.user}"


# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++




class UserProduct(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)

    def __str__(self):
        return f"UserProduct User: {self.user}, Product Name: {self.product.product_name}"



class Cart(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    is_paid = models.BooleanField(default=False)
    razor_pay_order_id = models.CharField(max_length=1000, null=True, blank=True)
    razor_pay_payment_id = models.CharField(max_length=1000, null=True, blank=True)
    razor_pay_payment_signature = models.CharField(max_length=1000, null=True, blank=True)

    sell_product = models.ForeignKey(Product, on_delete=models.CASCADE, null=True)

    def __str__(self):
        return self.razor_pay_order_id
    
