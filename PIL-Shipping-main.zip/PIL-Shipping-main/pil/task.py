# tasks.py

from celery import shared_task
from datetime import timezone
from decimal import Decimal
from .models import *
import requests

@shared_task(bind=True)
def daily_payout_task(self):
    print('helloooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo')
    print('helloooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo')
    print('helloooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo')
    print('helloooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo')
    print('helloooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo')
    today_date = timezone.now().date()
    purchases = Purchase.objects.all()
    daily_payouts = DailyPayout.objects.all()
    custom_users = CustomUser.objects.all()

    for user in custom_users:
        user_purchases = purchases.filter(user=user)

        if user_purchases.exists():
            user_daily_payouts = daily_payouts.filter(user=user)

            for daily_payout in user_daily_payouts:
                if today_date == daily_payout.payout_date:

                    user_today_earnings = float(daily_payout.product.product_daily)
                    total_days = int(daily_payout.product.product_cycle)
                    total_payout_amount = total_days * Decimal(daily_payout.product.product_daily)
                    user_earnings = total_payout_amount

                    user_earnings_obj, created = UserEarn.objects.get_or_create(user=user)
                    user_earnings_obj.user_today_earnings = user_today_earnings
                    user_earnings_obj.user_earnings = user_earnings
                    user_earnings_obj.save()
