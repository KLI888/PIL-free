from django.contrib import admin
from .models import Product, CustomUser, Cart, UserProduct, Purchase, DailyPayout, UserEarn, WithdrawRequest

# Register your models here.
admin.site.register(Product)
admin.site.register(CustomUser)
admin.site.register(Cart)
admin.site.register(UserProduct)
admin.site.register(Purchase)
admin.site.register(DailyPayout)
admin.site.register(UserEarn)
admin.site.register(WithdrawRequest)