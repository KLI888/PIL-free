from django.shortcuts import render, redirect, HttpResponse
from django.contrib.auth import authenticate, login, logout
from .models import *
from django.contrib.auth.models import User
from .models import CustomUser  
import razorpay
from decimal import Decimal
from django.utils import timezone
from .task import *
from django.core.exceptions import ObjectDoesNotExist
from django.http import JsonResponse

from django.contrib.auth.decorators import login_required
from django.db import transaction

from django.contrib.auth import get_user_model
User = get_user_model()
# Create your views here.
from datetime import datetime

def home(request):
    

    return render(request, 'index.html')


def login_view(request):
    if request.method == "POST":
        phone_number = request.POST.get('number')
        password = request.POST.get('password')

        phone_number = phone_number

        # Authenticate using the 'phone_number' field
        user = authenticate(request, phone_number=phone_number, password=password)   

        if user is not None:
            login(request, user)
            return redirect('/home')
    return render(request, 'login.html')


def register(request):
    if request.method == "POST":
        username = request.POST.get('name')
        phone_number = request.POST.get('phone')
        password = request.POST.get('password')
        passwordAg = request.POST.get('password-again')

        if phone_number is not None:
            phone_number = phone_number
        if password != passwordAg:
            return render(request, 'register.html', {'error_message': 'Passwords do not match'})

        try:
            user = CustomUser.objects.get(phone_number=phone_number)
            return render(request, 'login.html', {'error_message': 'User with this phone number already exists'})
        except CustomUser.DoesNotExist:
            user = CustomUser.objects.create_user(phone_number=phone_number, username=username, password=password)
            
            # Log in the user after registration
            login(request, user)

            userEarn = UserEarn.objects.create(user=user, user_earnings=0, user_today_earnings=0)

            return redirect('/')
    
    return render(request, 'register.html')

def logoutPage(request):
    logout(request)
    return redirect('/')


from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned
from .models import UserEarn  # Import your UserEarn model

def myacc(request):
    try:
        userEarn = UserEarn.objects.get(user=request.user)
    except ObjectDoesNotExist:
        # If the UserEarn instance does not exist, create a new one
        userEarn = UserEarn.objects.create(user=request.user, user_earnings=0, user_today_earnings=0)
    except MultipleObjectsReturned:
        # If multiple instances exist, handle it based on your requirements
        # For example, you can choose one of the instances or log the issue
        userEarn = UserEarn.objects.filter(user=request.user).first()

    context = {"userEarn": userEarn}
    return render(request, 'myacc.html', context)

def myTeam(request):
     return render(request, 'myTeam.html')

def product(request):
    products = Product.objects.all()
    context = {
          'products': products
     }
    return render(request, 'product.html', context)


def success(request):
    razorpay_order_id = request.GET.get('razorpay_order_id')
    razorpay_payment_id = request.GET.get('razorpay_payment_id')
    razorpay_signature = request.GET.get('razorpay_signature')

    cart = Cart.objects.get(razor_pay_order_id= razorpay_order_id)
    cart.is_paid = True
    cart.razor_pay_payment_id = razorpay_payment_id
    cart.razor_pay_payment_signature = razorpay_signature
    cart.save()

    userProduct = UserProduct.objects.create(user = request.user,product=cart.sell_product)
    userProduct.save()
    return HttpResponse('Payment Successful')


def withdrawRecord(request):
    return render(request, 'withdrawRecord.html')



@login_required
def withdrawBal(request):
    if request.method == "POST":
        name = request.POST.get('name')
        phone_number = request.POST.get('phone')
        email = request.POST.get('email')
        upi_id = request.POST.get('upi_id')
        wid_amount = request.POST.get('wid_amount')

        if phone_number is not None:
            phone_number = "+91" + phone_number

            # Get the current user from the request
            user = request.user

            # Create a WithdrawRequest object with the user
            withdrawReq = WithdrawRequest.objects.create(
                user=user,
                name=name,
                phone_number=phone_number,
                user_email=email,
                user_upi=upi_id,
                wid_amount=wid_amount
            )
            withdrawReq.save()

    return render(request, 'withdrawForm.html')


@login_required
@transaction.atomic
def productView(request, id):
    try:
        product = Product.objects.get(id=id)

        client = razorpay.Client(auth=(settings.KEY, settings.SECRET))
        payment = client.order.create({
            'amount': int(product.product_price) * 100,
            'currency': 'USD',
            'payment_capture': 1
        })

        # Create a Cart object and associate it with the current user
        cart_obj = Cart.objects.create(
            user=request.user,
            razor_pay_order_id=payment['id'],
            sell_product=product
        )

        # Calculate total_days based on product_cycle
        total_days = int(product.product_cycle)

        # Calculate total payout amount based on product_cycle and product_daily
        total_payout_amount = total_days * Decimal(product.product_daily)

        purchase = Purchase.objects.create(
            user=request.user,
            product=product,
        )

        # Set next_day to 0
        next_day = 0

        # Loop through the days and add daily payout to user's earnings
        for day in range(total_days):
            # Create a DailyPayout instance for the day
            daily_payout = DailyPayout.objects.create(
                user=request.user,
                purchase=purchase,
                payout_amount=product.product_daily,
                payout_date=(datetime.now() + timedelta(days=day)).date()
            )

        context = {
            'product': product,
            'payment': payment,
        }
        return render(request, 'productBuy.html', context)

    except Product.DoesNotExist:
        return HttpResponse("Product not found.", status=404)
    except Exception as e:
        # Log the exception or handle it appropriately
        return HttpResponse(f"An error occurred: {str(e)}", status=500)


# calculate the user earnings on daily basis
def calcEarn(request):
    from django.utils import timezone
    import decimal  

    # ...

    # Assuming the code is inside a function or script
    print("Starting the earnings calculation process...")

    today_date = timezone.now().date()
    purchases = Purchase.objects.all()
    daily_payouts = DailyPayout.objects.all()
    custom_users = CustomUser.objects.all()

    for user in custom_users:
        user_purchases = purchases.filter(user=user)

        if user_purchases.exists():
            user_daily_payouts = daily_payouts.filter(user=user)
            user_earnings_obj, created = UserEarn.objects.get_or_create(user=user)

            user_earnings = user_earnings_obj.user_earnings  # Initialize user_earnings

            for daily_payout in user_daily_payouts:
                if today_date == daily_payout.payout_date:
                    # Access the related product through the Purchase
                    user_today_earnings = float(daily_payout.purchase.product.product_daily)
                    total_days = int(daily_payout.purchase.product.product_cycle)
                    total_payout_amount = total_days * Decimal(daily_payout.purchase.product.product_daily)

                    # Increment user_earnings
                    user_earnings += decimal.Decimal(user_today_earnings)

                    # Update the UserEarn object
                    user_earnings_obj.user_today_earnings = user_today_earnings
                    daily_payout.delete()

            # Move the increment outside the loop
            user_earnings_obj.user_earnings = user_earnings  # Update user_earnings
            user_earnings_obj.save()

    print("Earnings calculation process completed.")
    result = "Function executed successfully!"
    return redirect('/myacc')


