from django.urls import path
from .views import *

urlpatterns = [
    path('', login_view, name='login'),
    path('home/', home, name='home'),
    path('register/', register, name='register'),
    path('product/', product, name='product'),
    path('myTeam/', myTeam, name='myTeam'),
    path('withdrawRecord/', withdrawRecord, name='withdrawRecord'),
    path('withdrawBal/', withdrawBal, name='withdrawBal'),
    path('myacc/', myacc, name='myacc'),
    path('logoutPage/', logoutPage, name='logoutPage'),
    path('product/<int:id>', productView, name='productView'),
    path("product/success/", success, name="success"),
    path('calcEarn', calcEarn, name='calcEarn')

]
